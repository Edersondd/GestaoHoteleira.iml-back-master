package model.enums;

public enum TipoMidia {
    IMAGEM,
    VIDEO
}
